module org.example.demo2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.net.http;


    opens org.example.demo2 to javafx.fxml;
    exports org.example.demo2;
    exports org.example.demo2.model;
    opens org.example.demo2.model to javafx.fxml, com.google.gson;
}